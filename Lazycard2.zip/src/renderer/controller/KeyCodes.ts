enum KeyCodes {
    Space = 32,
    ArrowUp = 38,
    ArrowRight = 39,
    ArrowDown = 40
}

export default KeyCodes;